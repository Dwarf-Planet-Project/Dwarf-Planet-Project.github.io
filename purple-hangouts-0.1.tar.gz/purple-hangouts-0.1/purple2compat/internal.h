
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#include "win32/win32dep.h"
#endif

#include "../purplecompat.h"

#ifndef N_
#	define N_(a) (a)
#endif

#ifndef _
#	define _(a) (a)
#endif
